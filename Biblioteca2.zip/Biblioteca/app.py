from flask import Flask
from views import views 
# Crear una instancia de la aplicación Flask
app = Flask(__name__)

# Definir la ruta principal
app.register_blueprint(views, url_prefix='/')

# Punto de entrada para ejecutar la aplicación
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)