from flask import Blueprint, render_template

# Creación de un Blueprint llamado 'views' para organizar las rutas de la aplicación
views = Blueprint('views', __name__)

@views.route('/login')  # Ruta para la página de inicio de sesión
def login():
    return render_template('login.html')  # Renderiza la plantilla login.html

@views.route('/')  # Ruta principal de la aplicación
def start():
    return render_template('start.html')  # Renderiza la plantilla start.html

@views.route('/about')  # Ruta para la página "Acerca de"
def about():
    return render_template('about.html')  # Renderiza la plantilla about.html
