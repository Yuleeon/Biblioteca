from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash

db = SQLAlchemy()

class Usuario(db.Model):
    id_usuario = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(255), nullable=False)
    apellido = db.Column(db.String(255), nullable=False)  # Debe coincidir con la BD
    correo = db.Column(db.String(255), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)


    def __repr__(self):
        return f'<Usuario {self.nombre} - {self.correo}>'
       

class Categoria(db.Model):
    __tablename__ = 'categorias'
    
    id_categoria = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre_categoria = db.Column(db.String(255), nullable=False)
    descripcion = db.Column(db.String(255))
    
    def __repr__(self):
        return f'<Categoria {self.nombre_categoria}>'


class libro(db.Model):
    __tablename__ = 'libro'
    
    id_libro = db.Column(db.Integer, primary_key=True, autoincrement=True)
    titulo = db.Column(db.String(100), nullable=False)
    autor = db.Column(db.String(100))
    genero = db.Column(db.String(100))
    editorial = db.Column(db.String(100))
    ano_publicacion = db.Column(db.Date)
    sinopsis = db.Column(db.String(300))
    precio = db.Column(db.Numeric(10,2))
    imagen = db.Column(db.Text) 

    def __repr__(self):
        return f'<Libro {self.titulo} - {self.autor}>'

class administracion(db.Model):
    id_administracion = db.Column(db.Integer, primary_key=True)
    usuario = db.Column(db.String(100), nullable=False, unique=True)
    correo = db.Column(db.String(100), nullable=False, unique=True)
    contrasena = db.Column(db.String(255), nullable=False)  # Cambiado a 'contrasena'

    def __repr__(self):
        return f'<Administracion {self.usuario} - {self.correo}>'