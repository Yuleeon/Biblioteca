from flask import Flask

# Crear una instancia de la aplicación Flask
app = Flask(__name__)

# Definir la ruta principal
@app.route('/')
def hello_world():
    return 'Funen a cesar por no entrar a la junta'

# Punto de entrada para ejecutar la aplicación
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)