from flask import Flask, render_template, request, jsonify
import datetime
import re

# Crear una instancia de la aplicación Flask
app = Flask(__name__)

def validar_tarjeta(numero):
    """
    Valida que el número de tarjeta tenga exactamente 16 dígitos numéricos.
    
    Parámetros:
        numero (str): Número de tarjeta ingresado por el usuario.
    
    Retorna:
        bool: True si el número es válido, False en caso contrario.
    """
    return re.fullmatch(r"\d{16}", numero) is not None

def validar_fecha_expiracion(mes, anio):
    """
    Verifica que la fecha de expiración de la tarjeta sea válida y no esté vencida.
    
    Parámetros:
        mes (str): Mes de expiración de la tarjeta.
        anio (str): Año de expiración de la tarjeta.
    
    Retorna:
        tuple: (bool, str) - True y una cadena vacía si la fecha es válida, False y un mensaje de error en caso contrario.
    """
    hoy = datetime.datetime.now()
    try:
        mes = int(mes)
        anio = int(anio)
        if anio < hoy.year or (anio == hoy.year and mes < hoy.month):
            return False, "Error: La tarjeta está vencida"
        if not (1 <= mes <= 12):
            return False, "Error: El mes ingresado no es válido"
        return True, ""
    except ValueError:
        return False, "Error: Fecha de expiración inválida"

def validar_cvv(cvv):
    """
    Valida que el código CVV tenga 3 o 4 dígitos numéricos.
    
    Parámetros:
        cvv (str): Código de seguridad de la tarjeta.
    
    Retorna:
        bool: True si el CVV es válido, False en caso contrario.
    """
    return re.fullmatch(r"\d{3,4}", cvv) is not None

@app.route('/')
def index():
    """
    Ruta principal que renderiza el formulario de pago.
    
    Retorna:
        str: Página HTML con el formulario de pago.
    """
    return render_template('pago.html')

@app.route('/procesar_pago', methods=['POST'])
def procesar_pago():
    """
    Ruta para procesar los datos del pago enviados por el usuario.
    
    Recibe:
        JSON con los siguientes datos:
            - numero_tarjeta (str): Número de tarjeta de crédito/débito.
            - mes_expiracion (str): Mes de expiración.
            - anio_expiracion (str): Año de expiración.
            - cvv (str): Código de seguridad.
    
    Retorna:
        JSON con un mensaje de éxito o error.
    """
    datos = request.json
    numero_tarjeta = datos.get('numero_tarjeta')
    mes_expiracion = datos.get('mes_expiracion')
    anio_expiracion = datos.get('anio_expiracion')
    cvv = datos.get('cvv')

    # Validar el número de tarjeta
    if not validar_tarjeta(numero_tarjeta):
        return jsonify({'mensaje': 'Error: Número de tarjeta inválido'}), 400

    # Validar la fecha de expiración
    fecha_valida, mensaje_fecha = validar_fecha_expiracion(mes_expiracion, anio_expiracion)
    if not fecha_valida:
        return jsonify({'mensaje': mensaje_fecha}), 400

    # Validar el CVV
    if not validar_cvv(cvv):
        return jsonify({'mensaje': 'Error: CVV inválido'}), 400

    return jsonify({'mensaje': 'Pago exitoso'})

if __name__ == '__main__':
    # Ejecutar la aplicación en modo depuración
    app.run(debug=True)
