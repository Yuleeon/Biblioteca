from flask import Flask, render_template, request, jsonify
from datetime import datetime
import re

# Crear una instancia de la aplicación Flask
app = Flask(__name__)

def validate_card_number(card_number):
    """
    Valida que el número de tarjeta tenga entre 13 y 19 dígitos numéricos.
    
    Parámetros:
        card_number (str): Número de tarjeta ingresado por el usuario.
    
    Retorna:
        bool: True si el número es válido, False en caso contrario.
    """
    return bool(re.fullmatch(r"\d{13,19}", card_number))

def validate_expiry_date(expiry_month, expiry_year):
    """
    Verifica que la fecha de expiración de la tarjeta sea válida y no esté vencida.
    
    Parámetros:
        expiry_month (int): Mes de expiración de la tarjeta.
        expiry_year (int): Año de expiración de la tarjeta.
    
    Retorna:
        bool: True si la tarjeta no ha expirado, False en caso contrario.
    """
    current_year = datetime.now().year
    current_month = datetime.now().month
    if expiry_year < current_year or (expiry_year == current_year and expiry_month < current_month):
        return False
    return True

def validate_cvv(cvv, card_number):
    """
    Valida que el código CVV sea correcto según el tipo de tarjeta.
    
    Parámetros:
        cvv (str): Código de seguridad de la tarjeta.
        card_number (str): Número de tarjeta para determinar el tipo de tarjeta.
    
    Retorna:
        bool: True si el CVV es válido, False en caso contrario.
    """
    if len(card_number) in [15]:  # American Express usa un CVV de 4 dígitos
        return len(cvv) == 4
    return len(cvv) == 3  # Visa, Mastercard, etc., usan un CVV de 3 dígitos

@app.route('/')
def index():
    """
    Ruta principal que renderiza el formulario de pago.
    
    Retorna:
        str: Página HTML con el formulario de pago.
    """
    return render_template('payment.html')

@app.route('/process_payment', methods=['POST'])
def process_payment():
    """
    Ruta para procesar los datos del pago enviados por el usuario.
    
    Recibe:
        JSON con los siguientes datos:
            - card_number (str): Número de tarjeta de crédito/débito.
            - expiry_month (int): Mes de expiración.
            - expiry_year (int): Año de expiración.
            - cvv (str): Código de seguridad.
    
    Retorna:
        JSON con un mensaje de éxito o error.
    """
    data = request.json
    card_number = data.get('card_number', '').replace(' ', '')
    expiry_month = int(data.get('expiry_month', 0))
    expiry_year = int(data.get('expiry_year', 0))
    cvv = data.get('cvv', '')
    
    # Validar el número de tarjeta
    if not validate_card_number(card_number):
        return jsonify({'success': False, 'message': 'Número de tarjeta inválido'}), 400
    
    # Validar la fecha de expiración
    if not validate_expiry_date(expiry_month, expiry_year):
        return jsonify({'success': False, 'message': 'La tarjeta está expirada'}), 400
    
    # Validar el CVV
    if not validate_cvv(cvv, card_number):
        return jsonify({'success': False, 'message': 'CVV inválido'}), 400
    
    return jsonify({'success': True, 'message': 'Pago procesado exitosamente (simulado)'}), 200

if __name__ == '__main__':
    # Ejecutar la aplicación en modo depuración
    app.run(debug=True)
