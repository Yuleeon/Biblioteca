from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify,render_template_string, make_response
from base import db, Usuario, administracion
from functools import wraps
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64, hashlib, jwt, datetime, re


SECRET_KEY = 'odi0UvM3'
clave_secreta = b'mi_clave_secreta_32bytes_12asdaa'
iv = b'Paparapipiaste*-'

#claves secretas para admin
CLAVE_ADMIN = 's4qu3nm3_d3_uvmXDa'
clave_secretaa = b'h0la_/3st4/cl4v3+tu-n0-l4/t13n3s'
ivv = b'P4p4r4p1p145t3*/'

views = Blueprint('views', __name__)

def verificar_clave_admin(clave_ingresada):
    return clave_ingresada == CLAVE_ADMIN

def ajustar_padding_base64(base64_string):
    padding_needed = len(base64_string) % 4
    if padding_needed != 0:
        base64_string += '=' * (4 - padding_needed)
    return base64_string

def encrypt_email_ad(email):
    cipher = AES.new(clave_secretaa, AES.MODE_CBC, ivv)
    padding_length = 16 - len(email) % 16
    email_padded = email + chr(padding_length) * padding_length  # PKCS7 Padding
    encrypted_email = cipher.encrypt(email_padded.encode())
    return base64.b64encode(encrypted_email).decode()  # Guardamos en Base64
def decrypt_email_ad(encrypted_email):
    encrypted_data = base64.b64decode(encrypted_email)
    cipher = AES.new(clave_secretaa, AES.MODE_CBC, ivv)
    decrypted_email = cipher.decrypt(encrypted_data).decode()
    return decrypted_email.rstrip(decrypted_email[-1])



def encrypt_email(email):
    cipher = AES.new(clave_secreta, AES.MODE_CBC, iv)
    padding_length = 16 - len(email) % 16
    email_padded = email + chr(padding_length) * padding_length  # PKCS7 Padding
    encrypted_email = cipher.encrypt(email_padded.encode())
    return base64.b64encode(encrypted_email).decode()  # Guardamos en Base64
def decrypt_email(encrypted_email):
    encrypted_data = base64.b64decode(encrypted_email)
    cipher = AES.new(clave_secreta, AES.MODE_CBC, iv)
    decrypted_email = cipher.decrypt(encrypted_data).decode()
    return decrypted_email.rstrip(decrypted_email[-1])  # Quita el padding


# Decorador para proteger rutas de admin
def token_admin(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        # Obtener el token desde las cookies
        token_base64 = request.cookies.get('admin_token')  # Leer el token desde la cookie
        if not token_base64:
            flash('Acceso no autorizado. Inicia sesión.', 'danger')
            return redirect(url_for('views.ad_log'))  # Redirigir al login si no hay token

        try:
            # Decodificar el token de Base64
            token = base64.b64decode(token_base64).decode()

            # Decodificar el JWT
            data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])

            # Buscar el usuario administrador
            current_user = administracion.query.filter_by(id_administracion=data['user_id']).first()

            if not current_user:
                flash('Sesión inválida. Inicia sesión de nuevo.', 'danger')
                return redirect(url_for('views.ad_log'))  # Redirigir si no se encuentra el usuario
        except Exception as e:
            flash('Sesión inválida. Inicia sesión de nuevo.', 'danger')
            return redirect(url_for('views.ad_log'))  # Redirigir si ocurre un error en el token

        # Si todo está bien, pasar el usuario actual a la vista
        return f(current_user, *args, **kwargs)

    return decorated


def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token_base64 = request.cookies.get('token')  # Leer el token desde la cookie
        if not token_base64:
            flash('Acceso no autorizado. Inicia sesión.', 'danger')
            return redirect(url_for('views.login'))

        try:
            token = base64.b64decode(token_base64).decode()
            data = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
            current_user = Usuario.query.filter_by(id_usuario=data['user_id']).first()
        except Exception as e:
            flash('Sesión inválida. Inicia sesión de nuevo.', 'danger')
            return redirect(url_for('views.login'))

        return f(current_user, *args, **kwargs)
    return decorated




@views.route('/')
def start():
    return render_template('start.html')

@views.route('/robots.txt')
def robots():
    return render_template_string('''
    {% extends "layout.html" %}

    {% block content %}
        <div class="container text-center mt-5">
            <h1 class="display-3 fw-bold text-success">¡Felicidades metiche!</h1>
            <h2 class="display-5 text-primary">Encontraste una flag:</h2>

            <!-- Contenedor adicional para centrar más la flag -->
            <div class="d-flex justify-content-center align-items-center mt-4">
                <h2 class="display-12 text-primary">
                    YULEEON_ctf{¿Bu5c45_vUlneRAbIlIdAdEs_M3j0r_h4z_un_sc4n_4_tU_4atuEst1m4_tE_h4cE_f4LtA_3Res_f4c1l_c0m0_uN_MD5}
                </h2>
            </div>

            <img src="{{ url_for('static', filename='images/robot.jpeg') }}" alt="Flag" class="img-fluid mt-4" style="max-width: 300px;">
        </div>
    {% endblock %}
    ''')

@views.route('/about')
def about():
    return render_template('about.html')


@views.route('/payment')
@token_required
def index(current_user):
    return render_template('payment.html')

@views.route('/carrito')
@token_required
def carrito(current_user):
    return render_template('carrito.html')

@views.route('/opiniones')
@token_required
def opiniones(current_user):
    return render_template('opiniones.html')

@views.route('/final_compra')
@token_required
def final_compra(current_user):
    return render_template('final_compra.html')

@views.route('/view_libro')
@token_admin
def view_libro(current_user):
    return render_template('view_libro.html')

@views.route('/editar_lib', methods=['GET', 'POST'])
@token_admin  
def editar_lib(current_user):
    return render_template('editar_lib.html', usuario=current_user)

@views.route('/forgetpassw')
def forgetpassw():
    return render_template('forgetpassw.html')

@views.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        nombre = request.form.get('nombre')
        apellido = request.form.get('apellidos')
        correo = request.form.get('correo')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if password != confirm_password:
            flash('Las contraseñas no coinciden.', 'danger')
            return redirect(url_for('views.registro'))

        usuario_existente = Usuario.query.all()
        if any(decrypt_email(u.correo) == correo for u in usuario_existente):
            flash('El correo ya está registrado.', 'danger')
        else:
            hashed_password = hashlib.sha256(password.encode()).hexdigest()
            encrypted_email = encrypt_email(correo)

            nuevo_usuario = Usuario(
                nombre=nombre,
                apellido=apellido,
                correo=encrypted_email,
                password=hashed_password
            )
            db.session.add(nuevo_usuario)
            db.session.commit()

            flash('Registro exitoso. Ahora puedes iniciar sesión.', 'success')
            return redirect(url_for('views.login'))  # Redirigir a la página de login

    return render_template('registro.html')

@views.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo = request.form.get('correo')
        password = request.form.get('password')

        usuarios = Usuario.query.all()
        usuario = next((u for u in usuarios if decrypt_email(u.correo) == correo), None)

        if usuario:
            hashed_password_ingresada = hashlib.sha256(password.encode()).hexdigest()

            if usuario.password == hashed_password_ingresada:
                token = jwt.encode({
                    'user_id': usuario.id_usuario,
                    'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
                }, SECRET_KEY, algorithm='HS256')

                token_base64 = base64.b64encode(token.encode()).decode()

                response = make_response(redirect(url_for('views.books')))  # Redirigir a la página de libros o dashboard
                response.set_cookie('token', token_base64, httponly=True, samesite='Strict')  # Guardar el token en una cookie segura

                flash('Inicio de sesión exitoso.', 'success')
                return response
            else:
                flash('Correo o contraseña incorrectos.', 'danger')
        else:
            flash('Correo o contraseña incorrectos.', 'danger')

    return render_template('login.html')

#Registro administradores
@views.route('/admin', methods=['GET', 'POST'])
def admin():
    if request.method == 'POST':
        usuario = request.form.get('usuario')
        correo = request.form.get('correo')
        contraseña = request.form.get('contraseña')
        confirmar_contraseña = request.form.get('confirmar_contraseña')
        clave_ingresada = request.form.get('clave_admin')

        # Verificar la clave administrativa
        if not verificar_clave_admin(clave_ingresada):
            flash('Clave administrativa incorrecta', 'danger')
            return redirect(url_for('views.admin'))

        # Verificar que las contraseñas coincidan
        if contraseña != confirmar_contraseña:
            flash('Las contraseñas no coinciden', 'danger')
            return redirect(url_for('views.admin'))

        # Verificar si el correo ya está registrado como administrador
        administradores = administracion.query.all()
        if any(admin.correo == correo for admin in administradores):
            flash('El correo ya está registrado como administrador.', 'danger')
            return redirect(url_for('views.admin'))

        # Hashear la contraseña con SHA256
        hashed_password = hashlib.sha256(contraseña.encode()).hexdigest()

        # Crear el nuevo administrador
        nuevo_admin = administracion(
            usuario=usuario,
            correo=correo,  # No encriptamos el correo en este caso
            contrasena=hashed_password
        )

        try:
            db.session.add(nuevo_admin)
            db.session.commit()
            flash('Administrador registrado con éxito', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error al registrar administrador: {str(e)}', 'danger')
            print(f'Error al registrar administrador: {str(e)}')  # Depuración
            return redirect(url_for('views.admin'))

        return redirect(url_for('views.ad_log'))  # Redirige al login

    return render_template('admin.html')


@views.route('/ad_log', methods=['GET', 'POST'])
def ad_log():
    if request.method == 'POST':
        usuario = request.form.get('usuario')
        password = request.form.get('password')

        # Buscar administrador por usuario
        admin = administracion.query.filter_by(usuario=usuario).first()

        if admin and admin.contrasena == hashlib.sha256(password.encode()).hexdigest():
            # Si las credenciales son correctas, generar el token JWT
            token_payload = {
                'user_id': admin.id_administracion,
                'is_admin': True,
                'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
            }
            
            # Codificar el token JWT
            token = jwt.encode(token_payload, SECRET_KEY, algorithm='HS256')
            
            # Codificar el token en Base64
            token_b64 = base64.b64encode(token.encode()).decode()

            # Crear la respuesta con el redireccionamiento a view_libro
            response = make_response(redirect(url_for('views.view_libro')))
            response.set_cookie('admin_token', token_b64, httponly=True, samesite='Strict')
            
            return response

        flash('Credenciales incorrectas', 'danger')
        return render_template('ad_log.html')

    return render_template('ad_log.html')

@views.route('/logout')
def logout():
    response = make_response(redirect(url_for('views.login'))) #redirigir a la página de login
    response.set_cookie('token', '', expires=0)  # Eliminar la cookie
    flash('Sesión cerrada correctamente.', 'success')
    return response

@views.route('/books')
def books():
    libros = [
        {
            'titulo': 'La Comunidad del Anillo',
            'autor': 'J.R.R. Tolkien',
            'genero': 'Fantasía',
            'editorial': 'Minotauro',
            'isbn': '9788445000663',
            'año_publicacion': 1954,
            'disponibilidad': 5,
            'imagen': 'anillos1.jpeg'
        },
        {
            'titulo': 'Las Dos Torres',
            'autor': 'J.R.R. Tolkien',
            'genero': 'Fantasía',
            'editorial': 'Minotauro',
            'isbn': '9788445000670',
            'año_publicacion': 1954,
            'disponibilidad': 3,
            'imagen': 'anillos2.jpeg'
        },
        {
            'titulo': 'El Retorno del Rey',
            'autor': 'J.R.R. Tolkien',
            'genero': 'Fantasía',
            'editorial': 'Minotauro',
            'isbn': '9788445000687',
            'año_publicacion': 1955,
            'disponibilidad': 0,
            'imagen': 'anillos3.jpeg'
        }
    ]
    return render_template('books.html', libros=libros)



# Payment validation functions and route
def validar_tarjeta(numero):
    """Valida que el número de tarjeta tenga 16 dígitos numéricos."""
    return re.fullmatch(r"\d{16}", numero) is not None

def validar_fecha_expiracion(mes, anio):
    """Verifica que la fecha de expiración sea válida y no esté vencida."""
    hoy = datetime.datetime.now()
    try:
        mes = int(mes)
        anio = int(anio)
        if anio < hoy.year or (anio == hoy.year and mes < hoy.month):
            return False, "Error: La tarjeta está vencida"
        if not (1 <= mes <= 12):
            return False, "Error: El mes ingresado no es válido"
        return True, ""
    except ValueError:
        return False, "Error: Fecha de expiración inválida"

def validar_cvv(cvv):
    """Valida que el CVV tenga 3 o 4 dígitos numéricos."""
    return re.fullmatch(r"\d{3,4}", cvv) is not None

@views.route('/procesar_pago', methods=['POST'])
def procesar_pago():
    datos = request.json
    numero_tarjeta = datos.get('numero_tarjeta')
    mes_expiracion = datos.get('mes_expiracion')
    anio_expiracion = datos.get('anio_expiracion')
    cvv = datos.get('cvv')

    if not validar_tarjeta(numero_tarjeta):
        return jsonify({'mensaje': 'Error: Número de tarjeta inválido'}), 400

    fecha_valida, mensaje_fecha = validar_fecha_expiracion(mes_expiracion, anio_expiracion)
    if not fecha_valida:
        return jsonify({'mensaje': mensaje_fecha}), 400

    if not validar_cvv(cvv):
        return jsonify({'mensaje': 'Error: CVV inválido'}), 400

    return jsonify({'mensaje': 'Pago exitoso'})

