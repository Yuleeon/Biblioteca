CREATE DATABASE IF NOT EXISTS Biblioteca;
USE Biblioteca;

CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    apellido VARCHAR(255) NOT NULL,
    correo VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE libro (
    id_libro INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100),
    genero VARCHAR(100),
    editorial VARCHAR(100),
    isbn INT UNIQUE,
    ano_publicacion DATE,
    disponibilidad INT
);

CREATE TABLE editorial (
    id_editorial INT PRIMARY KEY AUTO_INCREMENT,
    id_libro INT,
    fecha DATE,
    pais INT,
    FOREIGN KEY (id_libro) REFERENCES libro(id_libro)
);

CREATE TABLE categorias (
    id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nombre_categoria VARCHAR(255) NOT NULL,
    descripcion VARCHAR(255)
);

CREATE TABLE descarga (
    id_obra INT PRIMARY KEY AUTO_INCREMENT,
    tipo_obra VARCHAR(255),
    valor INT,
    material VARCHAR(255),
    autor VARCHAR(255),
    ano VARCHAR(4),
    almacen VARCHAR(255)
);


CREATE TABLE pago (
    id_pago INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    monto DECIMAL(10,2),
    metodo_pago VARCHAR(50),
    fecha_pago DATE,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

CREATE TABLE administracion (
    id_administracion INT PRIMARY KEY AUTO_INCREMENT,
    usuario VARCHAR(255) NOT NULL UNIQUE,
    correo VARCHAR(255) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL
);
