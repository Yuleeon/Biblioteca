CREATE DATABASE IF NOT EXISTS Biblioteca;
USE Biblioteca;

CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    apellido VARCHAR(255) NOT NULL,
    correo VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE libro (
    id_libro INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100),
    genero VARCHAR(100),
    editorial VARCHAR(100),
    ano_publicacion DATE,
    sinopsis VARCHAR(300),
    precio INT NOT NULL
);


CREATE TABLE categorias (
    id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nombre_categoria VARCHAR(255) NOT NULL,
    descripcion VARCHAR(255)
);



CREATE TABLE administracion (
    id_administracion INT PRIMARY KEY AUTO_INCREMENT,
    usuario VARCHAR(255) NOT NULL UNIQUE,
    correo VARCHAR(255) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL
);


INSERT INTO categorias (nombre_categoria, descripcion) VALUES 
('Ficción', 'Libros de narrativa imaginativa'),
('Ciencia Ficción', 'Historias con tecnología y ciencia avanzada'),
('Fantasía', 'Relatos con elementos mágicos y mundos imaginarios'),
('Misterio', 'Novelas de suspenso y resolución de crímenes'),
('Historia', 'Libros sobre eventos históricos y biografías'),
('Autoayuda', 'Libros para el desarrollo personal y motivación'),
('Negocios', 'Libros sobre economía, finanzas y emprendimiento'),
('Infantil', 'Libros para niños y jóvenes lectores'),
('Terror', 'Historias de miedo y suspenso sobrenatural'),
('Anime', 'Libros de manga y anime');