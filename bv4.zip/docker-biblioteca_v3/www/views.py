from flask import Blueprint, render_template
from base import *

views =  Blueprint('views',__name__)

@views.route('/login')
def login():
    return render_template('login.html')

@views.route('/usuarios')
def users():
    usuarios = Usuario_.query.all() 
    return render_template('usuarios.html',usuarios=usuarios)
    
@views.route('/')
def start():
    return render_template('start.html')

@views.route('/about')
def about():
    return render_template('about.html')
