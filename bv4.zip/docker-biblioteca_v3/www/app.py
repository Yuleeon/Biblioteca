from flask import Flask, render_template, Blueprint
from views import views
from base import db
# Crear una instancia de la aplicación Flask
app = Flask(__name__)

app.register_blueprint(views, url_prefix='/')

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://root:SuperSecretPassword123@db:3306/flaskdb'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)


# Punto de entrada para ejecutar la aplicación
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
    
    

