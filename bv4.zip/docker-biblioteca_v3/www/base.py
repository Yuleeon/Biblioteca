from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()
# Define una clase que representará una tabla de la base de datos
class Usuario_(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
        return f"<Usuario {self.nombre}>"


class Editorial(db.Model):
    __tablename__ = 'editorial'
    
    id_libro = db.Column(db.Integer, db.ForeignKey('libro.id_libro'), primary_key=True)
    id_editorial = db.Column(db.Integer, primary_key=True)
    fecha = db.Column(db.Date)
    pais = db.Column(db.Integer)  # Puede ser una referencia a una tabla de países o solo un valor numérico
    # Relación con la tabla "libro"
    libro = db.relationship('Libro', backref=db.backref('editoriales', lazy=True))
    
    def __repr__(self):
        return f'<Editorial {self.id_editorial} - {self.fecha}>'

class Categoria(db.Model):
    __tablename__ = 'categorias'
    
    id_categoria = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre_categoria = db.Column(db.String(255), nullable=False)
    descripcion = db.Column(db.String(255))
    
    def __repr__(self):
        return f'<Categoria {self.nombre_categoria}>'

class Descarga(db.Model):
    __tablename__ = 'descarga'
    
    id_obra = db.Column(db.Integer, primary_key=True, autoincrement=True)
    tipo_obra = db.Column(db.String(255))
    valor = db.Column(db.Integer)
    material = db.Column(db.String(255))
    autor = db.Column(db.String(255))
    año = db.Column(db.String(4))
    almacen = db.Column(db.String(255))
    
    def __repr__(self):
        return f'<Descarga {self.tipo_obra} - {self.valor}>'


class Usuario(db.Model):
    __tablename__ = 'usuario'
    
    id_usuario = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(255), nullable=False)
    correo = db.Column(db.String(255), unique=True)
    telefono = db.Column(db.String(20))
    tipo_usuario = db.Column(db.Integer)
    
    def __repr__(self):
        return f'<Usuario {self.nombre} - {self.correo}>'

class Administracion(db.Model):
    __tablename__ = 'administracion'
    
    id_usuario = db.Column(db.Integer, db.ForeignKey('usuario.id_usuario'), primary_key=True)
    nivel_acceso = db.Column(db.Integer)
    
    # Relación con la tabla "usuario"
    usuario = db.relationship('Usuario', backref=db.backref('administraciones', lazy=True))
    
    def __repr__(self):
        return f'<Administracion {self.id_usuario} - Nivel {self.nivel_acceso}>'


class Libro(db.Model):
    __tablename__ = 'libro'
    
    id_libro = db.Column(db.Integer, primary_key=True, autoincrement=True)
    titulo = db.Column(db.String(100), nullable=False)
    autor = db.Column(db.String(100))
    genero = db.Column(db.String(100))
    editorial = db.Column(db.String(100))
    isbn = db.Column(db.Integer, unique=True)
    año_publicacion = db.Column(db.Date)
    disponibilidad = db.Column(db.Integer)
    
    def __repr__(self):
        return f'<Libro {self.titulo} - {self.autor}>'




