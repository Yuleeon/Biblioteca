CREATE DATABASE IF NOT EXISTS Biblioteca;
USE Biblioteca;

CREATE TABLE libro (
    id_libro INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(100) NOT NULL,
    autor VARCHAR(100),
    genero VARCHAR(100),
    editorial VARCHAR(100),
    isbn INT UNIQUE,
    anio_publicacion DATE,
    disponibilidad INT
);

CREATE TABLE editorial (
    id_libro INT,
    id_editorial INT,
    fecha DATE,
    pais INT,
    PRIMARY KEY (id_libro, id_editorial),
    FOREIGN KEY (id_libro) REFERENCES libro(id_libro)
);

CREATE TABLE categorias (
    id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nombre_categoria VARCHAR(255) NOT NULL,
    descripcion VARCHAR(255)
);

CREATE TABLE descarga (
    id_obra INT PRIMARY KEY AUTO_INCREMENT,
    tipo_obra VARCHAR(255),
    valor INT,
    material VARCHAR(255),
    autor VARCHAR(255),
    anio VARCHAR(4),
    almacen VARCHAR(255)
);

CREATE TABLE usuario (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(255) NOT NULL,
    correo VARCHAR(255) UNIQUE,
    telefono VARCHAR(20),
    tipo_usuario INT
);

CREATE TABLE prestamo (
    id_prestamo INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    id_libro INT,
    fecha_inicio DATE,
    fecha_fin DATE,
    estado INT,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_libro) REFERENCES libro(id_libro)
);

CREATE TABLE administracion (
    id_usuario INT PRIMARY KEY,
    nivel_acceso INT,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);