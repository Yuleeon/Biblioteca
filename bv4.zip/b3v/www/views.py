from flask import Blueprint, render_template, request, jsonify
from base import *
from datetime import datetime
import re

views =  Blueprint('views',__name__)

@views.route('/login')
def login():
    return render_template('login.html')

@views.route('/usuarios')
def users():
    usuarios = Usuario_.query.all() 
    return render_template('usuarios.html',usuarios=usuarios)
    
@views.route('/')
def start():
    return render_template('start.html')

@views.route('/about')
def about():
    return render_template('about.html')

@views.route('/payment')
def index():
    return render_template('payment.html')

#payment 
def validar_tarjeta(numero):
    """Valida que el número de tarjeta tenga 16 dígitos numéricos."""
    return re.fullmatch(r"\d{16}", numero) is not None
def validar_fecha_expiracion(mes, anio):
    """Verifica que la fecha de expiración sea válida y no esté vencida."""
    hoy = datetime.now()
    try:
        mes = int(mes)
        anio = int(anio)
        if anio < hoy.year or (anio == hoy.year and mes < hoy.month):
            return False, "Error: La tarjeta está vencida"
        if not (1 <= mes <= 12):
            return False, "Error: El mes ingresado no es válido"
        return True, ""
    except ValueError:
        return False, "Error: Fecha de expiración inválida"

def validar_cvv(cvv):
    """Valida que el CVV tenga 3 o 4 dígitos numéricos."""
    return re.fullmatch(r"\d{3,4}", cvv) is not None

@views.route('/procesar_pago', methods=['POST'])
def procesar_pago():
    datos = request.json
    numero_tarjeta = datos.get('numero_tarjeta')
    mes_expiracion = datos.get('mes_expiracion')
    anio_expiracion = datos.get('anio_expiracion')
    cvv = datos.get('cvv')

    if not validar_tarjeta(numero_tarjeta):
        return jsonify({'mensaje': 'Error: Número de tarjeta inválido'}), 400

    fecha_valida, mensaje_fecha = validar_fecha_expiracion(mes_expiracion, anio_expiracion)
    if not fecha_valida:
        return jsonify({'mensaje': mensaje_fecha}), 400

    if not validar_cvv(cvv):
        return jsonify({'mensaje': 'Error: CVV inválido'}), 400

    return jsonify({'mensaje': 'Pago exitoso'})

#